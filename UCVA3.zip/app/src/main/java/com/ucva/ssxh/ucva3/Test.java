package com.ucva.ssxh.ucva3;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Lenovo on 2018/1/13.
 */

public class Test extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}

